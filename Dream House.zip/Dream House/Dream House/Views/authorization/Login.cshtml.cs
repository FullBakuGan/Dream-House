using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Dream_House.Views.authorization
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
